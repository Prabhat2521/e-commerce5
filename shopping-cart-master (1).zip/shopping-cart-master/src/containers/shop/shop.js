import React from "react";

const Shop = (props) => {
  return <div>Shop</div>;
};

export default Shop;
