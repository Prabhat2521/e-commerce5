import React from "react";

const About = (props) => {
  return <div>About</div>;
};

export default About;
