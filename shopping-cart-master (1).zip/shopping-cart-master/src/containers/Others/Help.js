import React from "react";

const Help = (props) => {
  return <div>Help</div>;
};

export default Help;
